


class Node:
    def __init__(self, val):
        self.val = val
    def addBlackEdge(self, node):
        self.blackEdge = node
    def addBlueEdge(self, node):
        self.blueEdge = node

class Eertree:
    def __init__(self):
        self.imaginaryString = Node("I")
        self.emptyString = Node("")
        self.imaginaryString.addBlueEdge(self.emptyString)

    def isPalindrome(self, string):
        if string == string[::-1]:
            return True
        return False

    def findLargestSubPalindrome(self,string):
        pass
         
    def addStringToTree(self, string):
        string  = string.lower()
        self.root = Node(string)
        node = self.root
        stack = [node]
        visited = []

        while stack != []:
            visiting = stack.pop()
            if visiting != self.imaginaryString and visiting != self.emptyString and visiting.val not in visited:
                    visited.append(visiting.val)
                    self.getBlackEdge(visiting)
                    self.getBlueEdge(visiting)
                    neighbors = [visiting.blackEdge, visiting.blueEdge]

                    for neighbor in neighbors:
                        if neighbor.val not in visited:
                            stack.append(neighbor)
                    
        self.visited = visited
        

    def getBlackEdge(self, node):
        if len(node.val) == 1:
            node.addBlackEdge(self.imaginaryString)  
        elif len(node.val) == 2:
            node.addBlackEdge(self.emptyString) 
        else:
            if node.val[0] == node.val[-1]:
                node.addBlackEdge(Node(node.val[1:(len(node.val)-1)])) 
            
       
    def getBlueEdge(self, node):
        if len(node.val) == 1:
            node.addBlueEdge(self.emptyString)
        else:
            end = len(node.val)-1
            string = node.val[0:end]
            while self.isPalindrome(string) != True:
                end -= 1
                string = node.val[0:end]
            node.addBlueEdge(Node(string))

        
    def getPalindromes(self):
        return self.visited

           
        
    
        
        


eertree = Eertree()
eertree.addStringToTree("Step on no pets")
lst = eertree.getPalindromes()

print(lst)